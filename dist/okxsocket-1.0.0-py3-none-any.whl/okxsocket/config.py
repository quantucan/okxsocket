#Public WebSocket: wss://ws.okx.com:8443/ws/v5/public
#Private WebSocket: wss://ws.okx.com:8443/ws/v5/private
#Public WebSocket: wss://wsaws.okx.com:8443/ws/v5/public
#Private WebSocket: wss://wsaws.okx.com:8443/ws/v5/private

wsslink = 'wss://ws.okx.com:8443/ws/v5/public'
apikey = '841b70dd-0d92-473e-8600-68c4fa6acc8f'
passphrase= 'sw5Trip+'
secretkey = 'A9F95CB87E987D825478EE1B67C4EF5B'
#IP = ""
#API name = "okx_api_key1"
#Permissions = "Read"

tg_token = '5981723192:AAFhCzOoxmpodrin3eELGVN-rbp9-SlU948'

SUBSCRIPTIONS = {'BTC-USDT' : [], 'ETH-USDT' : []}
CHAT_TASKS = {}
RUN = True